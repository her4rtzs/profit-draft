"""Staff endpoints for Phase 1: member management and front-desk check-in.

Mounted at /api/staff/. Who may call what comes from the shared RBAC policy in
apps/accounts/permissions.py, through the DRF adapters. This module adds no
capabilities. Business rules live in apps/membership/services.py.
"""

from datetime import date

from django.core.exceptions import ValidationError as DjangoValidationError
from django.db import transaction
from django.db.models import Prefetch, Q
from django.utils import timezone
from rest_framework import status, viewsets
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework.views import APIView

from apps.accounts.adapters import CanManageEnrollment, CanViewAttendance, CanViewFinancials
from apps.membership.models import Attendance, MemberProfile
from apps.billing.models import Payment, Subscription
from apps.finance.models import ManualPayment
from apps.trainers.models import TrainerAssignment
from apps.finance.services import monthly_summary, record_desk_payment, revenue_analytics
from apps.membership.services import (
    check_in_member,
    create_member,
    renew_member,
    update_member_profile,
)

from .serializers import (
    CheckInSerializer,
    RenewSerializer,
    EditPaymentSerializer,
    ManualPaymentSerializer,
    RecordPaymentSerializer,
    StaffAttendanceSerializer,
    StaffMemberCreateSerializer,
    StaffMemberSerializer,
    StaffMemberUpdateSerializer,
)


def _bad_request(exc):
    """Map a service-level rule failure to a 400 with a readable ``detail``."""
    return Response(
        {"detail": " ".join(exc.messages)},
        status=status.HTTP_400_BAD_REQUEST,
    )


class StaffMemberViewSet(viewsets.ModelViewSet):
    """Owner and Cashier manage members. Trainers may read a member's detail."""

    http_method_names = ["get", "post", "patch", "head", "options"]

    def get_permissions(self):
        if self.action == "retrieve":
            return [CanViewAttendance()]
        return [CanManageEnrollment()]

    def get_serializer_class(self):
        if self.action == "create":
            return StaffMemberCreateSerializer
        if self.action in ("update", "partial_update"):
            return StaffMemberUpdateSerializer
        return StaffMemberSerializer

    def get_queryset(self):
        queryset = (
            MemberProfile.objects.select_related("user")
            .prefetch_related(
                Prefetch(
                    "trainer_assignments",
                    queryset=TrainerAssignment.objects.filter(ended_at__isnull=True).select_related("trainer__user"),
                    to_attr="_active_assignments",
                ),
                Prefetch(
                    "manual_payments",
                    queryset=ManualPayment.objects.exclude(plan="").order_by("-created_at", "-id"),
                    to_attr="_prefetched_manual_payments",
                ),
                Prefetch(
                    "subscriptions",
                    queryset=Subscription.objects.exclude(plan="").order_by("-created_at", "-id"),
                    to_attr="_prefetched_subscriptions",
                ),
            )
            .order_by("user__username")
        )
        query = (self.request.query_params.get("q") or "").strip()
        if query:
            queryset = queryset.filter(
                Q(user__username__icontains=query)
                | Q(user__first_name__icontains=query)
                | Q(user__last_name__icontains=query)
                | Q(phone__icontains=query)
            )
        return queryset

    def create(self, request, *args, **kwargs):
        serializer = StaffMemberCreateSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        data = serializer.validated_data
        try:
            with transaction.atomic():
                profile = create_member(
                    name=data["name"],
                    email=data["email"],
                    password=data["password"],
                    phone=data.get("phone", ""),
                    address=data.get("address", ""),
                )
                if data.get("plan"):
                    renew_member(
                        profile,
                        data["plan"],
                        created_by=request.user,
                        start_date=data.get("start_date"),
                    )
        except DjangoValidationError as exc:
            return _bad_request(exc)
        profile.refresh_from_db()
        return Response(StaffMemberSerializer(profile).data, status=status.HTTP_201_CREATED)

    def update(self, request, *args, **kwargs):
        profile = self.get_object()
        serializer = StaffMemberUpdateSerializer(data=request.data, partial=True)
        serializer.is_valid(raise_exception=True)
        data = serializer.validated_data
        update_member_profile(
            profile,
            name=data.get("name"),
            phone=data.get("phone"),
            address=data.get("address"),
        )
        return Response(StaffMemberSerializer(profile).data)

    @action(detail=True, methods=["post"], url_path="renew")
    def renew(self, request, pk=None):
        profile = self.get_object()
        serializer = RenewSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        data = serializer.validated_data
        try:
            renew_member(
                profile,
                data["plan"],
                created_by=request.user,
                start_date=data.get("start_date"),
            )
        except DjangoValidationError as exc:
            return _bad_request(exc)
        profile.refresh_from_db()
        return Response(StaffMemberSerializer(profile).data)


class StaffCheckInView(APIView):
    """POST /api/staff/attendance/check-in/ with {"member_id": n}."""

    permission_classes = [CanViewAttendance]

    def post(self, request):
        serializer = CheckInSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        profile = (
            MemberProfile.objects.select_related("user")
            .filter(pk=serializer.validated_data["member_id"])
            .first()
        )
        if profile is None:
            return Response({"detail": "Member not found."}, status=status.HTTP_404_NOT_FOUND)
        try:
            record = check_in_member(profile, recorded_by=request.user)
        except DjangoValidationError as exc:
            return _bad_request(exc)
        return Response(StaffAttendanceSerializer(record).data)


class StaffAttendanceView(APIView):
    """GET /api/staff/attendance/?date=YYYY-MM-DD (defaults to today)."""

    permission_classes = [CanViewAttendance]

    def get(self, request):
        raw = request.query_params.get("date")
        try:
            day = date.fromisoformat(raw) if raw else timezone.localdate()
        except ValueError:
            return Response(
                {"detail": "date must be YYYY-MM-DD."},
                status=status.HTTP_400_BAD_REQUEST,
            )
        rows = (
            Attendance.objects.select_related("member__user")
            .filter(check_in_date=day)
            .order_by("check_in_at")
        )
        return Response(StaffAttendanceSerializer(rows, many=True).data)


class StaffPaymentView(APIView):
    """GET lists desk payments (optional ?member=<id>). POST records one and renews."""

    permission_classes = [CanManageEnrollment]

    def get(self, request):
        rows = ManualPayment.objects.select_related("member__user").order_by("-created_at", "-id")
        member_id = request.query_params.get("member")
        if member_id:
            if not member_id.isdigit():
                return Response({"detail": "member must be a number."}, status=status.HTTP_400_BAD_REQUEST)
            rows = rows.filter(member_id=int(member_id))
        data = list(ManualPaymentSerializer(rows[:200], many=True).data)
        online = Payment.objects.filter(status=Payment.Status.PAID).select_related("subscription__member__user")
        if member_id:
            online = online.filter(subscription__member_id=int(member_id))
        for p in online.order_by("-created_at")[:200]:
            user = p.subscription.member.user
            data.append({
                "id": f"online-{p.pk}", "ref": f"O-{p.pk:05d}", "member_id": p.subscription.member_id,
                "name": user.get_full_name() or user.username, "plan": p.subscription.plan or "monthly",
                "method": "ONLINE", "amount_centavos": p.amount_centavos,
                "paid_on": timezone.localdate(p.created_at).isoformat(), "created_at": p.created_at.isoformat(),
            })
        data.sort(key=lambda r: str(r["created_at"]), reverse=True)
        return Response(data[:200])

    def post(self, request):
        serializer = RecordPaymentSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        data = serializer.validated_data
        profile = MemberProfile.objects.select_related("user").filter(pk=data["member_id"]).first()
        if profile is None:
            return Response({"detail": "Member not found."}, status=status.HTTP_404_NOT_FOUND)
        try:
            payment = record_desk_payment(
                member=profile,
                plan=data["plan"],
                method=data["method"],
                recorded_by=request.user,
                paid_on=data.get("paid_on"),
            )
        except DjangoValidationError as exc:
            return _bad_request(exc)
        profile.refresh_from_db()
        return Response(
            {
                "payment": ManualPaymentSerializer(payment).data,
                "member": StaffMemberSerializer(profile).data,
            },
            status=status.HTTP_201_CREATED,
        )


class StaffPaymentDetailView(APIView):
    """PATCH or DELETE /api/staff/payments/<id>/ — Owner only. PATCH corrects the method or date of a desk payment; DELETE removes the record.

    Plan and amount stay fixed because the membership was extended from them.
    Online (PayMongo) payments are written only by the webhook and cannot be edited here.
    """

    permission_classes = [CanViewFinancials]

    def patch(self, request, pk):
        payment = ManualPayment.objects.select_related("member__user").filter(pk=pk).first()
        if payment is None:
            return Response({"detail": "Payment not found."}, status=status.HTTP_404_NOT_FOUND)
        serializer = EditPaymentSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        changed = []
        for field, value in serializer.validated_data.items():
            setattr(payment, field, value)
            changed.append(field)
        payment.save(update_fields=changed)
        return Response(ManualPaymentSerializer(payment).data)

    def delete(self, request, pk):
        """Remove a desk payment record. The member's expiry date is NOT rolled back."""
        deleted, _ = ManualPayment.objects.filter(pk=pk).delete()
        if not deleted:
            return Response({"detail": "Payment not found."}, status=status.HTTP_404_NOT_FOUND)
        return Response(status=status.HTTP_204_NO_CONTENT)


class StaffSummaryView(APIView):
    """GET /api/staff/reports/summary/?year=&month= — Owner only."""

    permission_classes = [CanViewFinancials]

    def get(self, request):
        today = timezone.localdate()
        try:
            year = int(request.query_params.get("year", today.year))
            month = int(request.query_params.get("month", today.month))
        except ValueError:
            return Response({"detail": "year and month must be numbers."}, status=status.HTTP_400_BAD_REQUEST)
        if not 1 <= month <= 12:
            return Response({"detail": "month must be 1 to 12."}, status=status.HTTP_400_BAD_REQUEST)
        return Response(monthly_summary(year, month))


class StaffRevenueAnalyticsView(APIView):
    """GET /api/staff/reports/revenue/?period=&year=&date=&offset= — Revenue analytics."""

    permission_classes = [CanViewFinancials]

    def get(self, request):
        period = request.query_params.get("period", "month")
        year = request.query_params.get("year")
        date_str = request.query_params.get("date")
        offset = request.query_params.get("offset", 0)
        data = revenue_analytics(period=period, year=year, anchor_date=date_str, offset=offset)
        return Response(data)


