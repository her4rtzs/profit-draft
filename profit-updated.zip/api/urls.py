"""DRF and session-auth routing for the ProFit web app and native shells, mounted at /api/."""

from django.urls import path
from rest_framework.routers import DefaultRouter

from . import auth
from .join import JoinCheckoutView, JoinConfirmView
from .member import MemberCheckInView, MemberCheckoutView, MemberMeView
from rest_framework.routers import SimpleRouter

from .trainers import (
    MemberTrainerRequestCancelView,
    MemberTrainerRequestView,
    MemberTrainerView,
    StaffMemberTrainerRemoveView,
    StaffMemberTrainerView,
    StaffTrainerCandidatesView,
    StaffTrainerDetailView,
    StaffTrainerListView,
    StaffTrainerResendInviteView,
    StaffTrainerRequestDecideView,
    StaffTrainerRequestListView,
    TrainerAnnouncementsView,
    TrainerAttendanceListView,
    TrainerCheckInView,
    TrainerDashboardView,
    TrainerMemberDetailView,
    TrainerMembersView,
    TrainerNotificationClearView,
    TrainerNotificationDeleteView,
    TrainerNotificationListView,
    TrainerNotificationReadAllView,
    TrainerNotificationReadView,
    TrainerProfileView,
    TrainerScheduleView,
)
from .announcements import (
    MemberAnnouncementListView,
    StaffAnnouncementArchiveView,
    StaffAnnouncementDetailView,
    StaffAnnouncementListView,
    StaffAnnouncementPublishView,
)
from .notifications import (
    NotificationClearView,
    NotificationDeleteView,
    NotificationListView,
    NotificationReadAllView,
    NotificationReadView,
)
from .staff import (
    StaffAttendanceView,
    StaffCheckInView,
    StaffMemberViewSet,
    StaffPaymentDetailView,
    StaffPaymentView,
    StaffRevenueAnalyticsView,
    StaffSummaryView,
)
from .views import MemberProfileViewSet, MyAttendanceViewSet

router = DefaultRouter()
router.register("membership", MemberProfileViewSet, basename="membership")
router.register("attendance", MyAttendanceViewSet, basename="attendance")

staff_router = SimpleRouter()
staff_router.register("staff/members", StaffMemberViewSet, basename="staff-members")

urlpatterns = [
    path("auth/csrf/", auth.csrf, name="auth-csrf"),
    path("auth/login/", auth.login_view, name="auth-login"),
    path("auth/logout/", auth.logout_view, name="auth-logout"),
    path("auth/session/", auth.session_view, name="auth-session"),
    path("auth/verify-password/", auth.verify_password_view, name="auth-verify-password"),
    path("auth/forgot-password/", auth.forgot_password_view, name="auth-forgot-password"),
    path("auth/reset-password/", auth.reset_password_view, name="auth-reset-password"),
    path("auth/change-password/", auth.change_password_view, name="auth-change-password"),
    path("join/checkout/", JoinCheckoutView.as_view(), name="join-checkout"),
    path("join/confirm/", JoinConfirmView.as_view(), name="join-confirm"),
    path("member/me/", MemberMeView.as_view(), name="member-me"),
    path("member/check-in/", MemberCheckInView.as_view(), name="member-checkin"),
    path("member/checkout/", MemberCheckoutView.as_view(), name="member-checkout"),
    path("staff/attendance/", StaffAttendanceView.as_view(), name="staff-attendance"),
    path("staff/attendance/check-in/", StaffCheckInView.as_view(), name="staff-checkin"),
    path("staff/payments/", StaffPaymentView.as_view(), name="staff-payments"),
    path("staff/payments/<int:pk>/", StaffPaymentDetailView.as_view(), name="staff-payment-detail"),
    path("staff/reports/summary/", StaffSummaryView.as_view(), name="staff-summary"),
    path("staff/reports/revenue/", StaffRevenueAnalyticsView.as_view(), name="staff-revenue-analytics"),
    path("notifications/", NotificationListView.as_view(), name="notifications"),
    path("notifications/read-all/", NotificationReadAllView.as_view(), name="notifications-read-all"),
    path("notifications/clear/", NotificationClearView.as_view(), name="notifications-clear"),
    path("notifications/<int:pk>/read/", NotificationReadView.as_view(), name="notification-read"),
    path("notifications/<int:pk>/", NotificationDeleteView.as_view(), name="notification-delete"),
    path("announcements/", MemberAnnouncementListView.as_view(), name="announcements"),
    path("staff/announcements/", StaffAnnouncementListView.as_view(), name="staff-announcements"),
    path("staff/announcements/<int:pk>/", StaffAnnouncementDetailView.as_view(), name="staff-announcement-detail"),
    path("staff/announcements/<int:pk>/publish/", StaffAnnouncementPublishView.as_view(), name="staff-announcement-publish"),
    path("staff/announcements/<int:pk>/archive/", StaffAnnouncementArchiveView.as_view(), name="staff-announcement-archive"),
    path("staff/trainers/", StaffTrainerListView.as_view(), name="staff-trainers"),
    path("staff/trainers/candidates/", StaffTrainerCandidatesView.as_view(), name="staff-trainer-candidates"),
    path("staff/trainers/<int:pk>/", StaffTrainerDetailView.as_view(), name="staff-trainer-detail"),
    path("staff/trainers/<int:pk>/resend-invite/", StaffTrainerResendInviteView.as_view(), name="staff-trainer-resend-invite"),
    path("staff/members/<int:pk>/trainer/", StaffMemberTrainerView.as_view(), name="staff-member-trainer"),
    path("staff/members/<int:pk>/trainer/remove/", StaffMemberTrainerRemoveView.as_view(), name="staff-member-trainer-remove"),
    path("staff/trainer-requests/", StaffTrainerRequestListView.as_view(), name="staff-trainer-requests"),
    path("staff/trainer-requests/<int:pk>/decide/", StaffTrainerRequestDecideView.as_view(), name="staff-trainer-request-decide"),
    path("trainer/me/", MemberTrainerView.as_view(), name="member-trainer"),
    path("trainer/profile/", TrainerProfileView.as_view(), name="trainer-profile"),
    path("trainer/dashboard/", TrainerDashboardView.as_view(), name="trainer-dashboard"),
    path("trainer/members/", TrainerMembersView.as_view(), name="trainer-members"),
    path("trainer/members/<int:pk>/", TrainerMemberDetailView.as_view(), name="trainer-member-detail"),
    path("trainer/attendance/", TrainerAttendanceListView.as_view(), name="trainer-attendance"),
    path("trainer/attendance/check-in/", TrainerCheckInView.as_view(), name="trainer-checkin"),
    path("trainer/announcements/", TrainerAnnouncementsView.as_view(), name="trainer-announcements"),
    path("trainer/notifications/", TrainerNotificationListView.as_view(), name="trainer-notifications"),
    path("trainer/notifications/read-all/", TrainerNotificationReadAllView.as_view(), name="trainer-notifications-read-all"),
    path("trainer/notifications/clear/", TrainerNotificationClearView.as_view(), name="trainer-notifications-clear"),
    path("trainer/notifications/<int:pk>/read/", TrainerNotificationReadView.as_view(), name="trainer-notification-read"),
    path("trainer/notifications/<int:pk>/", TrainerNotificationDeleteView.as_view(), name="trainer-notification-delete"),
    path("trainer/schedule/", TrainerScheduleView.as_view(), name="trainer-schedule"),
    path("trainer/schedule/note/", TrainerScheduleView.as_view(), name="trainer-schedule-note"),
    path("trainer-requests/", MemberTrainerRequestView.as_view(), name="member-trainer-request"),
    path("trainer-requests/<int:pk>/cancel/", MemberTrainerRequestCancelView.as_view(), name="member-trainer-request-cancel"),
    *staff_router.urls,
    *router.urls,
]
