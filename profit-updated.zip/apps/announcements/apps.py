from django.apps import AppConfig


class AnnouncementsConfig(AppConfig):
    name = "apps.announcements"
    default_auto_field = "django.db.models.BigAutoField"
    verbose_name = "Announcements"
