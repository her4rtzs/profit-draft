# Phase 11 — one bundle: portal UI, sidebar/logo, load animation, health form, editable payment history

Replaces portal-ui.css from phases 10, 10b and 10c (their fixes are included here).

## Files
- Payment history: Owner can also delete a desk payment (record only; expiry is not rolled back).
- Fixes: row action menu no longer clipped, lone stat card spans the row, sidebar labels and account block.
- Member photo now saved on the server (migration membership 0003) and shown in the header and profile; phone and address also saved. Name and email are read-only for server accounts.
- Sidebar and member portal redesign; splash plays on a fresh visit or after 10 quiet minutes (add ?splash=1 to force).
- Dashboard: recent registrations as soft rows with an anchored menu, membership legend fixed, notifications restyled, sidebar scrollbar only when needed.
- Members page and member portal controls: search pill, banner, segmented filters, table, switches, moods, swatches, class rows, dialogs, ripple on buttons.
- web/welcome.html: plan cards centred and full-width on phones, price no longer wraps.
- web/portal-ui.css (new, full): sidebar offset on desktop, centred logo in the collapsed sidebar, member portal redesign, health & goals form layout, staff polish, payment edit modal.
- web/portal-fx.js (new): top progress bar, scroll reveal, smooth page-to-page fade.
- web/splash.js: new intro (glow, double ring, letter rise, loading bar, curtain opens). Once per tab session. Now also on join.html.
- web/payments.html, web/pages.js, web/data.js: "Payment history" tab with search and an Edit button (desk payments).
- api/staff.py, api/serializers.py, api/urls.py: PATCH /api/staff/payments/<id>/ (Owner only; method and paid_on only).
- apps/finance/tests/test_payment_edit.py: tests for the edit endpoint.
- web/*.html: link portal-ui.css and portal-fx.js. web/sw.js: cache v4.

No migration needed.
